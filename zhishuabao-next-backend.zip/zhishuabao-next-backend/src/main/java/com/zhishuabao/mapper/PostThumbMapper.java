package com.zhishuabao.mapper;

import com.zhishuabao.model.entity.PostThumb;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 帖子点赞数据库操作
 *
 * @author <a href="https://github.com/wahahahhaha">被遗忘的南极熊</a>
 *  
 */
public interface PostThumbMapper extends BaseMapper<PostThumb> {

}




